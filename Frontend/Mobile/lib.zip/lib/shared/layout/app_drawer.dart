import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/theme/app_colors.dart';
import '../../cubits/child_mode/child_mode_cubit.dart';
import '../../cubits/child_mode/child_mode_state.dart';

import '../../screens/auth/login_screen.dart';
import '../../screens/profile/profile_screen.dart';

import '../../services/auth/auth_service.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: BlocConsumer<ChildModeCubit, ChildModeState>(
        listener: (context, state) {
          if (state is ChildModePinRequired) {
            _showSetPinSheet(context);
          }
        },
        builder: (context, state) {
          final childState = state is ChildModeStatus
              ? state
              : ChildModeStatus(isChildMode: false, hasPin: false);

          final isChildMode = childState.isChildMode;
          final hasPin = childState.hasPin;
          final isLoading = childState.isLoading;

          return SafeArea(
            child: Column(
              children: [
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(24),
                  color: AppColors.primary,
                  child: const Text(
                    "Talento",
                    style: TextStyle(color: Colors.white, fontSize: 20),
                  ),
                ),

                const SizedBox(height: 10),

                ListTile(
                  leading: const Icon(Icons.person),
                  title: const Text("Profile"),
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ProfileScreen(),
                      ),
                    );
                  },
                ),

                ListTile(
                  leading: const Icon(Icons.child_care),
                  title: Text(
                    isChildMode ? "Child Mode ON" : "Child Mode",
                  ),
                  trailing: Switch(
                    value: isChildMode,
                    onChanged: isLoading
                        ? null
                        : (_) => _handleChildMode(
                      context,
                      isChildMode,
                      hasPin,
                    ),
                  ),
                  onTap: isLoading
                      ? null
                      : () => _handleChildMode(
                    context,
                    isChildMode,
                    hasPin,
                  ),
                ),

                const Spacer(),

                ListTile(
                  leading: const Icon(Icons.logout, color: Colors.red),
                  title: const Text("Logout"),
                  onTap: () async {
                    context.read<ChildModeCubit>().reset();
                    await AuthService().logout();

                    Navigator.pushAndRemoveUntil(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const LoginScreen(),
                      ),
                          (route) => false,
                    );
                  },
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  // ==============================
  // CHILD MODE FLOW
  // ==============================
  void _handleChildMode(
      BuildContext context,
      bool isChildMode,
      bool hasPin,
      ) {
    Navigator.pop(context); // close drawer أولاً

    if (isChildMode) {
      _showDisableDialog(context);
      return;
    }

    if (!hasPin) {
      _showSetPinSheet(context);
      return;
    }

    context.read<ChildModeCubit>().enableChildMode();
    context.read<ChildModeCubit>().checkChildMode();
  }

  // ==============================
  // SET PIN BOTTOM SHEET (FIXED)
  // ==============================
  void _showSetPinSheet(BuildContext context) {
    final pin = TextEditingController();
    final confirm = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: const EdgeInsets.all(20),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              const Text("Set PIN"),

              TextField(
                controller: pin,
                keyboardType: TextInputType.number,
                maxLength: 4,
                obscureText: true,
              ),

              TextField(
                controller: confirm,
                keyboardType: TextInputType.number,
                maxLength: 4,
                obscureText: true,
              ),

              ElevatedButton(
                onPressed: () async {
                  if (pin.text != confirm.text) return;

                  final cubit = ctx.read<ChildModeCubit>();

                  await cubit.setPin(pin.text);
                  await cubit.enableChildMode();
                  await cubit.checkChildMode();

                  if (ctx.mounted) Navigator.pop(ctx);

                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(
                      content: Text("PIN saved successfully"),
                    ),
                  );
                },
                child: const Text("Save"),
              ),
            ],
          ),
        );
      },
    );
  }

  // ==============================
  // DISABLE DIALOG
  // ==============================
  void _showDisableDialog(BuildContext context) {
    final pin = TextEditingController();

    showDialog(
      context: context,
      builder: (ctx) {
        return AlertDialog(
          title: const Text("Disable Child Mode"),
          content: TextField(
            controller: pin,
            obscureText: true,
            keyboardType: TextInputType.number,
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text("Cancel"),
            ),
            ElevatedButton(
              onPressed: () async {
                final cubit = context.read<ChildModeCubit>();

                await cubit.disableChildMode(pin.text);
                await cubit.checkChildMode();

                if (ctx.mounted) Navigator.pop(ctx);
              },
              child: const Text("Confirm"),
            ),
          ],
        );
      },
    );
  }
}