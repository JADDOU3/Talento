import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../models/childmode/child_model.dart';
import '../../../cubits/profile/profile_cubit.dart';

class ChildrenSection extends StatelessWidget {
  final List<ChildModel> children;
  final ChildModel? selectedChild;
  final Function(ChildModel)? onChildSelected;

  const ChildrenSection({
    super.key,
    required this.children,
    this.selectedChild,
    this.onChildSelected,
  });

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'مستكشفيني',
          style: AppTextStyles.bodyLarge.copyWith(
            fontWeight: FontWeight.w700,
            color: AppColors.textPrimary,
          ),
        ),
        const SizedBox(height: 12),
        SizedBox(
          height: 90,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: children.length + 1,
            separatorBuilder: (_, __) => const SizedBox(width: 12),
            itemBuilder: (context, i) {
              if (i == children.length) {
                return _buildAddButton(context);
              }
              return _buildChildItem(context, children[i]);
            },
          ),
        ),
      ],
    );
  }

  Widget _buildChildItem(BuildContext context, ChildModel child) {
    final isSelected = selectedChild?.id == child.id;

    return GestureDetector(
      onTap: () {
        if (onChildSelected != null) {
          onChildSelected!(child);
        } else {
          context.read<ProfileCubit>().selectChild(child);
        }
      },
      onLongPress: () => _showChildInfoDialog(context, child),
      child: Column(
        children: [
          Container(
            width: 56,
            height: 56,
            decoration: BoxDecoration(
              shape: BoxShape.circle,
              border: Border.all(
                color: isSelected ? AppColors.primary : Colors.transparent,
                width: 2.5,
              ),
            ),
            child: ClipOval(
              child: child.avatarUrl != null
                  ? Image.network(
                child.avatarUrl!,
                fit: BoxFit.cover,
              )
                  : Container(
                color: AppColors.inputFill,
                child: const Icon(Icons.person),
              ),
            ),
          ),
          const SizedBox(height: 6),
          Text(
            child.name,
            style: AppTextStyles.bodyMedium.copyWith(
              fontSize: 12,
              color:
              isSelected ? AppColors.primary : AppColors.textSecondary,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildAddButton(BuildContext context) {
    return const SizedBox();
  }

  void _showChildInfoDialog(BuildContext context, ChildModel child) {
    showDialog(
      context: context,
      builder: (_) => AlertDialog(
        title: Text(child.name),
        content: Text('Child info'),
      ),
    );
  }
}