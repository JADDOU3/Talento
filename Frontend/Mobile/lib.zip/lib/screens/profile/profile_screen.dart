import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../shared/layout/app_drawer.dart';
import '../../shared/widgets/app_background.dart';
import '../../shared/layout/top_bar.dart';
import '../../shared/layout/bottom_nav_bar.dart';

import '../../cubits/profile/profile_cubit.dart';
import '../../cubits/profile/profile_state.dart';
import '../../cubits/child_mode/child_mode_cubit.dart';
import '../../cubits/child_mode/child_mode_state.dart';

import '../home/new_user.dart';

import 'widgets/available_kits_section.dart';
import 'widgets/children_section.dart';
import 'widgets/profile_header.dart';
import 'widgets/profile_progress_card.dart';
import 'widgets/settings_section.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return BlocProvider(
      create: (_) => ProfileCubit()..loadProfile(),
      child: const _ProfileView(),
    );
  }
}

class _ProfileView extends StatelessWidget {
  const _ProfileView();

  @override
  Widget build(BuildContext context) {
    final childModeState = context.watch<ChildModeCubit>().state;

    final isChildMode =
        childModeState is ChildModeStatus &&
            childModeState.isChildMode;

    return Scaffold(
      drawer: const AppDrawer(),
      body: AppBackground(
        child: Column(
          children: [
            const TopBar(),

            Expanded(
              child: BlocConsumer<ProfileCubit, ProfileState>(
                builder: (context, state) {
                  if (state is ProfileLoading) {
                    return const Center(child: CircularProgressIndicator());
                  }

                  if (state is ProfileLoaded ||
                      state is ProfileKitsLoading) {
                    final user = state is ProfileLoaded
                        ? state.user
                        : (state as ProfileKitsLoading).user;

                    final children = state is ProfileLoaded
                        ? state.children
                        : (state as ProfileKitsLoading).children;

                    final selectedChild = state is ProfileLoaded
                        ? state.selectedChild
                        : (state as ProfileKitsLoading).selectedChild;

                    final kits =
                    state is ProfileLoaded ? state.kits : [];

                    final displayName = isChildMode
                        ? (selectedChild?.name ?? user.name)
                        : user.name;

                    return SingleChildScrollView(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: Column(
                        children: [
                          const SizedBox(height: 12),

                          ProfileHeader(
                            name: displayName,
                            email: user.email,
                            avatarUrl: user.avatarUrl ?? '',
                          ),

                          const SizedBox(height: 24),

                          ChildrenSection(
                            children: children,
                            selectedChild: selectedChild,
                            onChildSelected: (child) {
                              context
                                  .read<ProfileCubit>()
                                  .selectChild(child);

                              Future.delayed(
                                const Duration(milliseconds: 150),
                                    () {
                                  context
                                      .read<ChildModeCubit>()
                                      .checkChildMode();
                                },
                              );
                            },
                          ),

                          const SizedBox(height: 24),

                          const ProfileProgressCard(
                            level: 'المستوى 3',
                            progress: 0.7,
                          ),

                          const SizedBox(height: 24),

                          Row(
                            mainAxisAlignment:
                            MainAxisAlignment.spaceBetween,
                            children: [
                              const Text('الحقائب'),
                              IconButton(
                                icon: const Icon(Icons.logout),
                                onPressed: () {
                                  context
                                      .read<ChildModeCubit>()
                                      .reset();

                                  Navigator.pushAndRemoveUntil(
                                    context,
                                    MaterialPageRoute(
                                      builder: (_) => const NewUser(),
                                    ),
                                        (r) => false,
                                  );
                                },
                              )
                            ],
                          ),

                          const SizedBox(height: 12),

                          AvailableKitsSection(kits: kits as dynamic),

                          const SizedBox(height: 24),

                          const SettingsSection(),
                        ],
                      ),
                    );
                  }

                  return const SizedBox();
                },
                listener: (context, state) {
                  if (state is ProfileError) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      SnackBar(content: Text(state.message)),
                    );
                  }
                },
              ),
            ),

            const BottomNavBar(selectedIndex: 4),
          ],
        ),
      ),
    );
  }
}