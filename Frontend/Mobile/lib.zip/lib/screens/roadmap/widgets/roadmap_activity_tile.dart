import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../models/roadmap/roadmap_activity_model.dart';

class RoadmapActivityTile extends StatelessWidget {
  final RoadmapActivityModel activity;
  final int index;
  final VoidCallback onTap;

  const RoadmapActivityTile({
    super.key,
    required this.activity,
    required this.index,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    final tileColor = _tileColor;
    final statusColor = _statusColor;
    final rotation = _rotationForIndex(index);

    return Transform.rotate(
      angle: activity.isLocked ? rotation * 0.45 : rotation,
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(32),
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 260),
            width: activity.isCurrent ? 188 : 170,
            padding: const EdgeInsets.fromLTRB(12, 12, 12, 11),
            decoration: BoxDecoration(
              color: tileColor,
              borderRadius: BorderRadius.circular(32),
              border: Border.all(
                color: activity.isCurrent
                    ? AppColors.white.withValues(alpha: 0.98)
                    : AppColors.white.withValues(alpha: 0.72),
                width: activity.isCurrent ? 2.6 : 1.7,
              ),
              boxShadow: [
                BoxShadow(
                  color: statusColor.withValues(
                    alpha: activity.isCurrent ? 0.38 : 0.18,
                  ),
                  blurRadius: activity.isCurrent ? 30 : 18,
                  offset: const Offset(0, 10),
                ),
              ],
            ),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                _StatusBadge(
                  activity: activity,
                  color: statusColor,
                ),
                const SizedBox(height: 6),
                _ActivityIcon(
                  activity: activity,
                  color: statusColor,
                ),
                const SizedBox(height: 8),
                Text(
                  activity.activityName.trim().isEmpty
                      ? 'نشاط ${index + 1}'
                      : activity.activityName,
                  textAlign: TextAlign.center,
                  maxLines: 2,
                  overflow: TextOverflow.ellipsis,
                  style: AppTextStyles.bodyLarge.copyWith(
                    color: activity.isLocked
                        ? AppColors.textPrimary
                        : AppColors.textPrimary,
                    fontWeight: FontWeight.w900,
                    fontSize: activity.isCurrent ? 14.8 : 14,
                    height: 1.18,
                  ),
                ),
                const SizedBox(height: 5),
                _ActivitySubtitle(activity: activity),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color get _tileColor {
    final colors = <Color>[
      AppColors.primary.withValues(alpha: 0.90),
      AppColors.yellow.withValues(alpha: 0.90),
      AppColors.secondary.withValues(alpha: 0.90),
      AppColors.pink.withValues(alpha: 0.90),
      const Color(0xFF48C5DC).withValues(alpha: 0.90),
    ];

    if (activity.isCompleted) {
      return AppColors.primary.withValues(alpha: 0.90);
    }

    if (activity.isCurrent) {
      return AppColors.pink.withValues(alpha: 0.92);
    }

    if (activity.isLocked) {
      return colors[index % colors.length].withValues(alpha: 0.46);
    }

    return colors[index % colors.length];
  }

  Color get _statusColor {
    if (activity.isCompleted) return AppColors.primary;
    if (activity.isCurrent) return AppColors.pink;
    return AppColors.textPrimary;
  }

  static double _rotationForIndex(int index) {
    final rotations = <double>[-0.040, 0.034, -0.024, 0.030];
    return rotations[index % rotations.length];
  }
}

class _ActivitySubtitle extends StatelessWidget {
  final RoadmapActivityModel activity;

  const _ActivitySubtitle({
    required this.activity,
  });

  @override
  Widget build(BuildContext context) {
    final text = _subtitle;
    final color = activity.isCurrent
        ? AppColors.white
        : AppColors.textPrimary;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 9, vertical: 3),
      decoration: BoxDecoration(
        color: activity.isCurrent
            ? AppColors.white.withValues(alpha: 0.20)
            : AppColors.white.withValues(alpha: 0.64),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Text(
        text,
        textAlign: TextAlign.center,
        maxLines: 1,
        overflow: TextOverflow.ellipsis,
        style: AppTextStyles.bodyMedium.copyWith(
          color: color,
          fontSize: 11.2,
          fontWeight: FontWeight.w900,
          height: 1.05,
        ),
      ),
    );
  }

  String get _subtitle {
    if (activity.isCompleted) {
      return 'مكتمل';
    }

    if (activity.isCurrent) {
      return activity.levelText.isEmpty ? 'النشاط الحالي' : activity.levelText;
    }

    return 'مغلق';
  }
}

class _ActivityIcon extends StatelessWidget {
  final RoadmapActivityModel activity;
  final Color color;

  const _ActivityIcon({
    required this.activity,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    if (activity.isCurrent) {
      return _PulsingIcon(activity: activity);
    }

    return Container(
      width: 60,
      height: 60,
      decoration: BoxDecoration(
        color: AppColors.white.withValues(
          alpha: activity.isLocked ? 0.82 : 0.92,
        ),
        shape: BoxShape.circle,
      ),
      child: Icon(
        _fallbackIcon,
        color: activity.isLocked ? AppColors.textPrimary : color,
        size: 31,
      ),
    );
  }

  IconData get _fallbackIcon {
    if (activity.isCompleted) return Icons.check_rounded;
    if (activity.isCurrent) return Icons.play_arrow_rounded;
    return Icons.lock_rounded;
  }
}

class _PulsingIcon extends StatefulWidget {
  final RoadmapActivityModel activity;

  const _PulsingIcon({
    required this.activity,
  });

  @override
  State<_PulsingIcon> createState() => _PulsingIconState();
}

class _PulsingIconState extends State<_PulsingIcon>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;
  late final Animation<double> _scale;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 950),
    )..repeat(reverse: true);

    _scale = Tween<double>(
      begin: 0.94,
      end: 1.08,
    ).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeInOut,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return ScaleTransition(
      scale: _scale,
      child: Container(
        width: 66,
        height: 66,
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.96),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.pink.withValues(alpha: 0.36),
              blurRadius: 22,
              spreadRadius: 3,
            ),
          ],
        ),
        child: const Icon(
          Icons.play_arrow_rounded,
          color: AppColors.pink,
          size: 39,
        ),
      ),
    );
  }
}

class _StatusBadge extends StatelessWidget {
  final RoadmapActivityModel activity;
  final Color color;

  const _StatusBadge({
    required this.activity,
    required this.color,
  });

  @override
  Widget build(BuildContext context) {
    final icon = activity.isCompleted
        ? Icons.check_rounded
        : activity.isCurrent
        ? Icons.auto_awesome_rounded
        : Icons.lock_rounded;

    return Align(
      alignment: Alignment.centerLeft,
      child: Container(
        width: 27,
        height: 27,
        decoration: BoxDecoration(
          color: AppColors.white.withValues(alpha: 0.94),
          shape: BoxShape.circle,
          boxShadow: [
            BoxShadow(
              color: AppColors.black.withValues(alpha: 0.04),
              blurRadius: 8,
              offset: const Offset(0, 3),
            ),
          ],
        ),
        child: Icon(
          icon,
          size: 16,
          color: activity.isLocked ? AppColors.textPrimary : color,
        ),
      ),
    );
  }
}