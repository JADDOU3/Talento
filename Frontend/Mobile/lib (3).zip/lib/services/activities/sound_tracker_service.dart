import 'dart:convert';

import '../../core/config/api_constants.dart';
import '../../models/activities/sound_tracker/sound_tracker_level_model.dart';
import '../auth/auth_api_client.dart';

class SoundTrackerService {
  final AuthApiClient _apiClient = AuthApiClient();

  Map<String, String> get _jsonHeaders => {
    'Content-Type': 'application/json',
  };

  Future<int> getSelectedChildId() async {
    final response = await _apiClient.get(
      Uri.parse(ApiConstants.selectedChild),
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'get selected child',
    );

    final data = jsonDecode(response.body);

    final childId = _readInt(data, ['id', 'childId']);

    if (childId == 0) {
      throw Exception('Selected child id was not found.');
    }

    return childId;
  }

  Future<Map<String, dynamic>?> getLatestSessionForChild(int childId) async {
    final uri = Uri.parse(ApiConstants.sessionsByChild(childId)).replace(
      queryParameters: {
        'page': '0',
        'size': '1',
        'sort': 'createdAt,desc',
      },
    );

    final response = await _apiClient.get(uri);

    print(
      'SOUND TRACKER: latest session response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'get latest session',
    );

    final data = jsonDecode(response.body);

    final content = data is Map ? data['content'] : null;

    if (content is! List || content.isEmpty) {
      return null;
    }

    final firstSession = content.first;

    if (firstSession is! Map) {
      return null;
    }

    return Map<String, dynamic>.from(firstSession);
  }

  Future<int> createSession({
    required int childId,
    required int kitId,
  }) async {
    final body = jsonEncode({
      'childId': childId,
      'kitId': kitId,
    });

    print('SOUND TRACKER: create session body = $body');

    final response = await _apiClient.post(
      Uri.parse(ApiConstants.sessions),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: create session response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'create session',
    );

    final data = jsonDecode(response.body);

    final sessionId = _readInt(data, ['id', 'sessionId']);

    if (sessionId == 0) {
      throw Exception('Created session id was not found.');
    }

    return sessionId;
  }

  Future<int> createActivitySession({
    required int activityId,
    required int sessionId,
  }) async {
    final body = jsonEncode({
      'orderIndex': activityId,
      'activityId': activityId,
      'sessionId': sessionId,
    });

    print('SOUND TRACKER: create activity session body = $body');

    final response = await _apiClient.post(
      Uri.parse(ApiConstants.activitySessions),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: create activity session response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'create activity session',
    );

    final data = jsonDecode(response.body);

    final activitySessionId = _readInt(data, [
      'id',
      'activitySessionId',
    ]);

    if (activitySessionId == 0) {
      throw Exception('Activity session id was not found.');
    }

    return activitySessionId;
  }

  Future<List<SoundTrackerLevelModel>> getLevelsByActivity(
      int activityId,
      ) async {
    final uri = Uri.parse(ApiConstants.levelsByActivity(activityId)).replace(
      queryParameters: {
        'page': '0',
        'size': '100',
        'sort': 'levelNumber,asc',
      },
    );

    print('SOUND TRACKER: get levels url = $uri');

    final response = await _apiClient.get(uri);

    print(
      'SOUND TRACKER: get levels response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'get levels',
    );

    final data = jsonDecode(response.body);

    final levels = SoundTrackerLevelModel.listFromPageResponse(data);

    if (levels.isEmpty) {
      throw Exception('No Sound Tracker levels were found.');
    }

    levels.sort((a, b) => a.levelNumber.compareTo(b.levelNumber));

    return levels;
  }

  Future<int> createLevelAttempt({
    required int attemptNumber,
    required String startedAt,
    required int activitySessionId,
    required int levelId,
  }) async {
    final body = jsonEncode({
      'attemptNumber': attemptNumber,
      'startedAt': startedAt,
      'endedAt': startedAt,
      'completed': false,
      'activitySessionId': activitySessionId,
      'levelId': levelId,
    });

    print('SOUND TRACKER: create level attempt body = $body');

    final response = await _apiClient.post(
      Uri.parse(ApiConstants.levelAttempts),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: create level attempt response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'create level attempt',
    );

    final data = jsonDecode(response.body);

    final attemptId = _readInt(data, [
      'id',
      'attemptId',
    ]);

    if (attemptId == 0) {
      throw Exception('Level attempt id was not found.');
    }

    return attemptId;
  }

  Future<void> updateLevelAttempt({
    required int attemptId,
    required int attemptNumber,
    required String startedAt,
    required int activitySessionId,
    required int levelId,
    required bool completed,
  }) async {
    final body = jsonEncode({
      'attemptNumber': attemptNumber,
      'startedAt': startedAt,
      'endedAt': DateTime.now().toIso8601String(),
      'completed': completed,
      'activitySessionId': activitySessionId,
      'levelId': levelId,
    });

    print('SOUND TRACKER: update level attempt body = $body');

    final response = await _apiClient.put(
      Uri.parse(ApiConstants.levelAttemptById(attemptId)),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: update level attempt response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'update level attempt',
    );
  }

  Future<void> postActivityEvent({
    required int childId,
    required int sessionId,
    required int activityId,
    required String action,
  }) async {
    final body = jsonEncode({
      'childId': childId,
      'sessionId': sessionId,
      'activityId': activityId,
      'action': action,
      'responseLanguage': 'en',
    });

    print('SOUND TRACKER: post activity event body = $body');

    final response = await _apiClient.post(
      Uri.parse(ApiConstants.activityEvents),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: post activity event response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'post activity event',
    );
  }

  Future<void> postLevelEvent({
    required int childId,
    required int sessionId,
    required int activitySessionId,
    required String action,
  }) async {
    final body = jsonEncode({
      'childId': childId,
      'sessionId': sessionId,
      'activitySessionId': activitySessionId,
      'action': action,
    });

    print('SOUND TRACKER: post level event body = $body');

    final response = await _apiClient.post(
      Uri.parse(ApiConstants.levelEvents),
      headers: _jsonHeaders,
      body: body,
    );

    print(
      'SOUND TRACKER: post level event response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'post level event',
    );
  }

  Future<void> completeActivitySession(int activitySessionId) async {
    final response = await _apiClient.put(
      Uri.parse(ApiConstants.activitySessionById(activitySessionId)),
      headers: _jsonHeaders,
    );

    print(
      'SOUND TRACKER: complete activity session response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'complete activity session',
    );
  }

  Future<void> endSession(int sessionId) async {
    final response = await _apiClient.patch(
      Uri.parse(ApiConstants.endSession(sessionId)),
      headers: _jsonHeaders,
    );

    print(
      'SOUND TRACKER: end session response = '
          '${response.statusCode} - ${_shortBody(response.body)}',
    );

    _ensureSuccess(
      response.statusCode,
      response.body,
      'end session',
    );
  }

  int readSessionId(Map<String, dynamic> session) {
    return _readInt(session, ['id', 'sessionId']);
  }

  int readKitId(Map<String, dynamic> session) {
    final directKitId = _readInt(session, ['kitId']);

    if (directKitId != 0) return directKitId;

    final kit = session['kit'];

    if (kit is Map) {
      return _readInt(kit, ['id', 'kitId']);
    }

    return 0;
  }

  int _readInt(dynamic source, List<String> keys) {
    if (source is! Map) return 0;

    for (final key in keys) {
      final value = source[key];

      if (value is int) return value;

      final parsed = int.tryParse(value?.toString() ?? '');

      if (parsed != null) return parsed;
    }

    return 0;
  }

  String _shortBody(String body) {
    if (body.length <= 800) return body;
    return '${body.substring(0, 800)}...';
  }

  void _ensureSuccess(
      int statusCode,
      String body,
      String actionName,
      ) {
    if (statusCode >= 200 && statusCode < 300) return;

    throw Exception(
      'Failed to $actionName. Status code: $statusCode. Body: $body',
    );
  }
}