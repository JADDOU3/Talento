import 'dart:collection';
import 'dart:math' as math;

import 'package:flame/components.dart';
import 'package:flame_forge2d/flame_forge2d.dart';
import 'package:flutter/material.dart';

import '../../../maze_engine/physics/maze_ball_component.dart';
import '../../../maze_engine/physics/maze_wall_component.dart';
import '../../../maze_engine/physics/tilt_gravity_behavior.dart';
import '../../../maze_engine/tilt/tilt_controller.dart';
import '../config/bodily_maze_level_config.dart';

class BodilyMazeGame extends Forge2DGame {
  BodilyMazeGame({
    required this.config,
    required this.tiltController,
    required this.onFellInHole,
    required this.onReachedEnd,
  }) : super(gravity: Vector2.zero(), zoom: 1);

  final MazeLevelConfig config;
  final TiltController tiltController;
  final VoidCallback onFellInHole;
  final VoidCallback onReachedEnd;

  MazeBallComponent? _ball;
  TiltGravityBehavior? _tiltBehavior;
  Vector2 _startPixel = Vector2.zero();

  bool _worldBuilt = false;
  bool _finished = false;

  // ── Jump state ─────────────────────────────────────────────────────────
  bool _isJumping = false;
  double _jumpTimer = 0;
  static const double _jumpDuration = 0.9;
  // جاذبية أضعف أثناء النط عشان الـ arch يكون أطول (أعرض)
  static const double _jumpGravity = 350.0;
  // القفزة العمودية الأساسية
  static const double _verticalImpulse = 380.0;
  // القفزة الأفقية (باتجاه الميلان) — هاي اللي بتنقل الكرة للجهة التانية
  static const double _horizontalImpulse = 300.0;
  // إذا الميلان ضعيف جداً، ندفع الكرة باتجاه أقرب حفرة
  static const double _minHorizontalImpulse = 200.0;

  // ── Trail ─────────────────────────────────────────────────────────────
  final Queue<Vector2> _trail = Queue();
  static const int _maxTrail = 25;
  Vector2? _jumpStartPos;

  // ── Auto jump ─────────────────────────────────────────────────────────
  double _autoJumpCooldown = 0;
  static const double _autoJumpProximity = 0.08;

  double _airborneTimer = 0;

  @override
  Color backgroundColor() => const Color(0x00000000);

  @override
  Future<void> onLoad() async {
    await super.onLoad();
    tiltController.start();
    final behavior = TiltGravityBehavior(tiltController: tiltController);
    _tiltBehavior = behavior;
    await add(behavior);
  }

  @override
  void onRemove() {
    tiltController.stop();
    super.onRemove();
  }

  @override
  void onGameResize(Vector2 gameSize) {
    super.onGameResize(gameSize);
    if (_worldBuilt || gameSize.x <= 0 || gameSize.y <= 0) return;
    _worldBuilt = true;
    _buildWorld(gameSize);
  }

  void _buildWorld(Vector2 s) {
    for (final r in config.wallRects) {
      final rect = Rect.fromLTWH(
          r.left * s.x, r.top * s.y, r.width * s.x, r.height * s.y);
      add(MazeWallComponent(
        position: Vector2(rect.center.dx, rect.center.dy),
        size: Vector2(rect.width, rect.height),
        color: const Color(0x00000000),
      ));
    }
    _startPixel = Vector2(config.startPoint.dx * s.x, config.startPoint.dy * s.y);
    final ball = MazeBallComponent(
      startPosition: _startPixel.clone(),
      radius: 5,
      color: const Color(0xFFF9B919),
    );
    _ball = ball;
    add(ball);
  }

  // ── Tap → jump ──────────────────────────────────────────────────────────
  void handleTap() {
    if (_ball == null || _finished) return;
    _doJump();
  }

  /// النطة الحقيقية — عمودي + أفقي حسب الميلان أو باتجاه الحفرة
  void _doJump() {
    if (_isJumping) return;
    _isJumping = true;
    _jumpTimer = _jumpDuration;
    _airborneTimer = _jumpDuration;
    _autoJumpCooldown = _jumpDuration + 0.4;
    _trail.clear();
    _jumpStartPos = _ball!.body.position.clone();

    // خفف الـ damping عشان الكرة تحافظ على السرعة الأفقية
    _ball!.setJumpingPhysics(true);

    // الجاذبية للأسفل بس أضعف عشان الـ arch يكون واسع
    world.gravity = Vector2(0, _jumpGravity);

    // ── اتجاه القفزة الأفقي ───────────────────────────────────────────
    // (1) جربي الميلان أولاً
    double horizontalDir = 0;
    // Y بالسنسور: موجب = خلف، سالب = أمام
    // بس المتاهة عمودية على الشاشة، فالحركة الأفقية بتصير من tiltX
    if (tiltController.tiltX.abs() > 0.5) {
      horizontalDir = -tiltController.tiltX.sign; // نفس اتجاه حركة الكرة
    } else {
      // (2) لو مافي ميلان واضح، ادفع الكرة باتجاه أقرب حفرة
      horizontalDir = _directionToNearestHole();
    }

    final horizontalImp =
        horizontalDir * math.max(_horizontalImpulse, _minHorizontalImpulse);

    _ball!.jumpWithDirection(Vector2(horizontalImp, -_verticalImpulse));
  }

  double _directionToNearestHole() {
    final ball = _ball;
    if (ball == null || config.holeRects.isEmpty) return 1.0;
    final pos = ball.body.position;
    final s = size;

    double nearestDx = double.infinity;
    for (final r in config.holeRects) {
      final cx = (r.left + r.width / 2) * s.x;
      final dx = cx - pos.x;
      if (dx.abs() < nearestDx.abs()) {
        nearestDx = dx;
      }
    }
    if (nearestDx == double.infinity || nearestDx.abs() < 1) return 1.0;
    return nearestDx.sign;
  }

  void _endJump() {
    _isJumping = false;
    _trail.clear();
    _jumpStartPos = null;
    _ball?.setJumpingPhysics(false);
    _tiltBehavior?.resetGravity();
  }

  // ── Hole detection ──────────────────────────────────────────────────────
  bool _isNearHole() {
    final ball = _ball;
    if (ball == null) return false;
    final s = size;
    final pos = ball.body.position;
    final prox = _autoJumpProximity * s.x;
    for (final r in config.holeRects) {
      final rect = Rect.fromLTWH(
        r.left * s.x - prox,
        r.top * s.y - prox,
        r.width * s.x + prox * 2,
        r.height * s.y + prox * 2,
      );
      if (rect.contains(Offset(pos.x, pos.y))) return true;
    }
    return false;
  }

  bool _isOverHole() {
    final ball = _ball;
    if (ball == null) return false;
    final s = size;
    final pos = ball.body.position;
    for (final r in config.holeRects) {
      final rect =
      Rect.fromLTWH(r.left * s.x, r.top * s.y, r.width * s.x, r.height * s.y);
      if (rect.contains(Offset(pos.x, pos.y))) return true;
    }
    return false;
  }

  bool _isAtEnd() {
    final ball = _ball;
    if (ball == null) return false;
    final s = size;
    final pos = ball.body.position;
    final c = Offset(config.endPoint.dx * s.x, config.endPoint.dy * s.y);
    final rPx = config.endPointRadius * s.x;
    final dx = pos.x - c.dx, dy = pos.y - c.dy;
    return (dx * dx + dy * dy) <= (rPx * rPx);
  }

  // ── Update loop ─────────────────────────────────────────────────────────
  @override
  void update(double dt) {
    super.update(dt);
    if (_finished || _ball == null) return;

    if (_autoJumpCooldown > 0) _autoJumpCooldown -= dt;
    if (_airborneTimer > 0) _airborneTimer -= dt;

    if (_isJumping) {
      _jumpTimer -= dt;
      _trail.addLast(_ball!.body.position.clone());
      if (_trail.length > _maxTrail) _trail.removeFirst();

      if (_jumpTimer <= 0) _endJump();
    }

    if (!_isJumping && _autoJumpCooldown <= 0 && _isNearHole()) {
      _doJump();
      return;
    }

    if (_isAtEnd()) {
      _finished = true;
      onReachedEnd();
      return;
    }

    if (!_isJumping && _airborneTimer <= 0 && _isOverHole()) {
      onFellInHole();
      _resetBall();
    }
  }

  // ── Render trail ────────────────────────────────────────────────────────
  @override
  void render(Canvas canvas) {
    super.render(canvas);

    if (_isJumping && _trail.length > 1) {
      final list = _trail.toList();

      // Trail dots
      for (int i = 0; i < list.length; i++) {
        final progress = i / list.length;
        final alpha = (progress * 0.7).clamp(0.0, 0.7);
        final radius = (1.5 + progress * 4).clamp(1.5, 5.5);
        final paint = Paint()
          ..color = const Color(0xFFF9B919).withValues(alpha: alpha)
          ..style = PaintingStyle.fill;
        canvas.drawCircle(Offset(list[i].x, list[i].y), radius, paint);
      }

      // Dashed line تربط النقاط
      final linePaint = Paint()
        ..color = const Color(0xFFF9B919).withValues(alpha: 0.35)
        ..style = PaintingStyle.stroke
        ..strokeWidth = 2;
      for (int i = 1; i < list.length; i += 2) {
        canvas.drawLine(
          Offset(list[i - 1].x, list[i - 1].y),
          Offset(list[i].x, list[i].y),
          linePaint,
        );
      }

      // Glow ring at start
      if (_jumpStartPos != null) {
        final glowProgress = (_jumpDuration - _jumpTimer) / _jumpDuration;
        final glowRadius = 6.0 + glowProgress * 24;
        final glowAlpha = (0.5 * (1 - glowProgress)).clamp(0.0, 0.5);
        final glowPaint = Paint()
          ..color = const Color(0xFFF9B919).withValues(alpha: glowAlpha)
          ..style = PaintingStyle.stroke
          ..strokeWidth = 2.5;
        canvas.drawCircle(
            Offset(_jumpStartPos!.x, _jumpStartPos!.y), glowRadius, glowPaint);
      }
    }
  }

  void _resetBall() {
    _ball?.resetToStart(_startPixel.clone());
    _airborneTimer = 0;
    _autoJumpCooldown = 0;
    _isJumping = false;
    _trail.clear();
    _jumpStartPos = null;
    _tiltBehavior?.resetGravity();
  }

  void calibrate() => tiltController.calibrate();
}
