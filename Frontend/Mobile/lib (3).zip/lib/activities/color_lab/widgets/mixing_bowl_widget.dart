import 'dart:math' as math;

import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../models/color_lab/color_lab_models.dart';

/// A hand-drawn cloud (bubble) that fills with the mixed color.
/// Shows the picked color chips and the live mixed result inside the cloud.
class MixingBowlWidget extends StatelessWidget {
  final List<ColorLabPaletteColor> selectedColors;

  const MixingBowlWidget({
    super.key,
    required this.selectedColors,
  });

  /// Average the picked colors to preview the mix.
  Color get _mixedColor {
    if (selectedColors.isEmpty) return AppColors.white;
    int r = 0, g = 0, b = 0;
    for (final c in selectedColors) {
      r += c.rgb[0];
      g += c.rgb[1];
      b += c.rgb[2];
    }
    final n = selectedColors.length;
    return Color.fromARGB(
      255,
      (r / n).round(),
      (g / n).round(),
      (b / n).round(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasColors = selectedColors.isNotEmpty;

    return AspectRatio(
      aspectRatio: 1.5,
      child: Stack(
        alignment: Alignment.center,
        children: [
          // The cloud shape, animated fill color
          Positioned.fill(
            child: TweenAnimationBuilder<Color?>(
              tween: ColorTween(
                begin: AppColors.white,
                end: _mixedColor,
              ),
              duration: const Duration(milliseconds: 350),
              builder: (context, color, _) {
                return CustomPaint(
                  painter: _CloudPainter(
                    fillColor: color ?? AppColors.white,
                    borderColor: AppColors.primary,
                  ),
                );
              },
            ),
          ),

          // Content inside the cloud
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 40, vertical: 24),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              mainAxisSize: MainAxisSize.min,
              children: [
                if (!hasColors)
                  Text(
                    'اختر لونًا لتبدأ الخلط',
                    textAlign: TextAlign.center,
                    style: AppTextStyles.bodyMedium.copyWith(
                      color: AppColors.textSecondary,
                      fontWeight: FontWeight.w700,
                      fontSize: 13,
                    ),
                  )
                else
                // Picked color chips
                  Wrap(
                    alignment: WrapAlignment.center,
                    spacing: 6,
                    runSpacing: 6,
                    children: selectedColors.map((c) {
                      return Container(
                        width: 26,
                        height: 26,
                        decoration: BoxDecoration(
                          color: c.color,
                          shape: BoxShape.circle,
                          border: Border.all(
                            color: AppColors.white,
                            width: 2,
                          ),
                          boxShadow: [
                            BoxShadow(
                              color: AppColors.black.withValues(alpha: 0.12),
                              blurRadius: 4,
                              offset: const Offset(0, 2),
                            ),
                          ],
                        ),
                      );
                    }).toList(),
                  ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// Draws a soft blob/cloud outline (like the design's hand-drawn bubble).
class _CloudPainter extends CustomPainter {
  final Color fillColor;
  final Color borderColor;

  _CloudPainter({
    required this.fillColor,
    required this.borderColor,
  });

  @override
  void paint(Canvas canvas, Size size) {
    final w = size.width;
    final h = size.height;

    // Build a wavy blob path using cubic curves around the rectangle.
    final path = Path();

    final cx = w / 2;
    final cy = h / 2;
    final rx = w * 0.44;
    final ry = h * 0.40;

    // 8 bumps around an ellipse to get a cloud-ish blob.
    const bumps = 9;
    final twoPi = 2 * math.pi;

    for (int i = 0; i <= bumps; i++) {
      final t = (i / bumps) * twoPi;
      // alternate radius to create bumps
      final wobble = (i.isEven) ? 1.0 : 0.86;
      final x = cx + rx * wobble * math.cos(t);
      final y = cy + ry * wobble * math.sin(t);

      if (i == 0) {
        path.moveTo(x, y);
      } else {
        // control point between previous and current, pushed outward
        final tPrev = ((i - 1) / bumps) * twoPi;
        final wobblePrev = ((i - 1).isEven) ? 1.0 : 0.86;
        final px = cx + rx * wobblePrev * math.cos(tPrev);
        final py = cy + ry * wobblePrev * math.sin(tPrev);

        final mx = (px + x) / 2 + (x - px) * 0.18;
        final my = (py + y) / 2 + (y - py) * 0.18;

        path.quadraticBezierTo(mx, my, x, y);
      }
    }
    path.close();

    // Fill
    final fillPaint = Paint()
      ..color = fillColor
      ..style = PaintingStyle.fill;
    canvas.drawPath(path, fillPaint);

    // Border (teal, hand-drawn look)
    final borderPaint = Paint()
      ..color = borderColor
      ..style = PaintingStyle.stroke
      ..strokeWidth = 3.5
      ..strokeJoin = StrokeJoin.round;
    canvas.drawPath(path, borderPaint);
  }

  @override
  bool shouldRepaint(covariant _CloudPainter old) =>
      old.fillColor != fillColor || old.borderColor != borderColor;
}