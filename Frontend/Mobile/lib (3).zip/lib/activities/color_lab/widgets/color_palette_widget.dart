import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../models/color_lab/color_lab_models.dart';

/// Shows clear, separate color circles the child taps to pick a color.
/// If a CHOICE palette image exists it is shown above the circles; if not,
/// the circles still render (using meta colors or a sensible default set).
class ColorPaletteWidget extends StatelessWidget {
  /// May be null if the backend has no CHOICE image for this level.
  final ColorLabImage? paletteImage;
  final ValueChanged<ColorLabPaletteColor> onColorPicked;

  const ColorPaletteWidget({
    super.key,
    required this.paletteImage,
    required this.onColorPicked,
  });

  @override
  Widget build(BuildContext context) {
    final slots = (paletteImage?.slots ?? 0) > 0 ? paletteImage!.slots : 5;
    final colors = _resolveColors(slots);

    return Column(
      children: [
        // Optional palette image (display only)
        if (paletteImage != null && paletteImage!.hasImage)
          ClipRRect(
            borderRadius: BorderRadius.circular(20),
            child: Image.network(
              paletteImage!.url,
              fit: BoxFit.contain,
              height: 110,
              errorBuilder: (_, __, ___) => const SizedBox.shrink(),
            ),
          ),

        if (paletteImage != null && paletteImage!.hasImage)
          const SizedBox(height: 14),

        // Clear, tappable color circles — ALWAYS shown
        Wrap(
          alignment: WrapAlignment.center,
          spacing: 14,
          runSpacing: 12,
          children: colors.map((c) {
            return _ColorButton(
              color: c,
              onTap: () => onColorPicked(c),
            );
          }).toList(),
        ),
      ],
    );
  }

  List<ColorLabPaletteColor> _resolveColors(int slots) {
    final fromMeta = paletteImage?.paletteColors ?? const [];
    if (fromMeta.isNotEmpty) return fromMeta;

    const fallback = [
      ColorLabPaletteColor(name: 'أحمر', hex: '#FF0000', rgb: [255, 0, 0]),
      ColorLabPaletteColor(name: 'أصفر', hex: '#FFD60A', rgb: [255, 214, 10]),
      ColorLabPaletteColor(name: 'أزرق', hex: '#0066FF', rgb: [0, 102, 255]),
      ColorLabPaletteColor(name: 'أبيض', hex: '#FFFFFF', rgb: [255, 255, 255]),
      ColorLabPaletteColor(name: 'أسود', hex: '#000000', rgb: [0, 0, 0]),
    ];

    return fallback.take(slots).toList();
  }
}

class _ColorButton extends StatelessWidget {
  final ColorLabPaletteColor color;
  final VoidCallback onTap;

  const _ColorButton({required this.color, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Material(
          color: Colors.transparent,
          shape: const CircleBorder(),
          child: InkWell(
            onTap: onTap,
            customBorder: const CircleBorder(),
            child: Container(
              width: 52,
              height: 52,
              decoration: BoxDecoration(
                color: color.color,
                shape: BoxShape.circle,
                border: Border.all(color: AppColors.white, width: 3),
                boxShadow: [
                  BoxShadow(
                    color: AppColors.black.withValues(alpha: 0.15),
                    blurRadius: 8,
                    offset: const Offset(0, 4),
                  ),
                ],
              ),
            ),
          ),
        ),
        if (color.name.trim().isNotEmpty) ...[
          const SizedBox(height: 4),
          Text(
            color.name,
            style: AppTextStyles.bodyMedium.copyWith(
              fontSize: 11,
              fontWeight: FontWeight.w700,
              color: AppColors.textSecondary,
            ),
          ),
        ],
      ],
    );
  }
}