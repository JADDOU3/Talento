import 'package:flutter/material.dart';

/// ===================== LEVEL =====================
/// One level of the Color Lab activity. Contains one CHOICE image
/// (the palette) and multiple TARGET images (the challenges).
class ColorLabLevel {
  final int id;
  final int levelNumber;
  final int difficulty;
  final String description;
  final List<ColorLabImage> images;

  const ColorLabLevel({
    required this.id,
    required this.levelNumber,
    required this.difficulty,
    required this.description,
    required this.images,
  });

  factory ColorLabLevel.fromJson(Map<String, dynamic> json) {
    return ColorLabLevel(
      id: _toInt(json['id']),
      levelNumber: _toInt(json['levelNumber']),
      difficulty: _toInt(json['difficulty']),
      description: (json['description'] ?? '').toString(),
      images: _parseImages(json['images']),
    );
  }

  /// The single palette image for this level (role == CHOICE).
  ColorLabImage? get paletteImage {
    for (final img in images) {
      if (img.isChoice) return img;
    }
    return null;
  }

  /// All target challenges (role == TARGET), sorted by sortOrder.
  List<ColorLabImage> get challenges {
    final targets = images.where((img) => img.isTarget).toList();
    targets.sort((a, b) => a.sortOrder.compareTo(b.sortOrder));
    return targets;
  }

  static List<ColorLabImage> _parseImages(dynamic value) {
    if (value is List) {
      return value
          .whereType<Map>()
          .map((e) => ColorLabImage.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }
    return <ColorLabImage>[];
  }

  static int _toInt(dynamic v) {
    if (v is int) return v;
    return int.tryParse(v?.toString() ?? '') ?? 0;
  }
}

/// ===================== IMAGE =====================
/// A single image inside a level. Either CHOICE (palette) or TARGET (object).
class ColorLabImage {
  final int id;
  final String s3Key;
  final String url;
  final String role; // CHOICE | TARGET
  final String label;
  final String description;
  final int sortOrder;
  final Map<String, dynamic> meta;

  const ColorLabImage({
    required this.id,
    required this.s3Key,
    required this.url,
    required this.role,
    required this.label,
    required this.description,
    required this.sortOrder,
    required this.meta,
  });

  factory ColorLabImage.fromJson(Map<String, dynamic> json) {
    return ColorLabImage(
      id: _toInt(json['id']),
      s3Key: (json['s3Key'] ?? '').toString(),
      url: (json['url'] ?? '').toString(),
      role: (json['role'] ?? '').toString().toUpperCase(),
      label: (json['label'] ?? '').toString(),
      description: (json['description'] ?? '').toString(),
      sortOrder: _toInt(json['sortOrder']),
      meta: _parseMeta(json['meta']),
    );
  }

  bool get isChoice => role == 'CHOICE';
  bool get isTarget => role == 'TARGET';
  bool get hasImage => url.trim().isNotEmpty;

  /// CHOICE only: number of color tap zones on the palette.
  int get slots => _toInt(meta['slots']);

  /// CHOICE only: the available colors on the palette (if backend provides them).
  /// Falls back to empty — coordinates/colors can be supplied by design team.
  List<ColorLabPaletteColor> get paletteColors {
    final raw = meta['colors'] ?? meta['palette'];
    if (raw is List) {
      return raw
          .whereType<Map>()
          .map((e) =>
              ColorLabPaletteColor.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }
    return <ColorLabPaletteColor>[];
  }

  /// TARGET only: the target color(s) the child must match.
  List<ColorLabTargetColor> get targetColors {
    final raw = meta['targetColors'] ?? meta['targetColor'];
    if (raw is List) {
      return raw
          .whereType<Map>()
          .map((e) =>
              ColorLabTargetColor.fromJson(Map<String, dynamic>.from(e)))
          .toList();
    }
    if (raw is Map) {
      return [
        ColorLabTargetColor.fromJson(Map<String, dynamic>.from(raw)),
      ];
    }
    return <ColorLabTargetColor>[];
  }

  /// TARGET only: primary target color (first one).
  ColorLabTargetColor? get primaryTarget =>
      targetColors.isNotEmpty ? targetColors.first : null;

  static Map<String, dynamic> _parseMeta(dynamic value) {
    if (value is Map) return Map<String, dynamic>.from(value);
    return <String, dynamic>{};
  }

  static int _toInt(dynamic v) {
    if (v is int) return v;
    return int.tryParse(v?.toString() ?? '') ?? 0;
  }
}

/// ===================== TARGET COLOR =====================
/// The color the child is trying to match, from a TARGET image's meta.
class ColorLabTargetColor {
  final String name;
  final String hex;
  final List<int> rgb;

  const ColorLabTargetColor({
    required this.name,
    required this.hex,
    required this.rgb,
  });

  factory ColorLabTargetColor.fromJson(Map<String, dynamic> json) {
    return ColorLabTargetColor(
      name: (json['name'] ?? '').toString(),
      hex: (json['hex'] ?? '').toString(),
      rgb: _parseRgb(json['rgb'], json['hex']),
    );
  }

  Color get color => _hexToColor(hex, rgb);

  static List<int> _parseRgb(dynamic rgbValue, dynamic hexValue) {
    if (rgbValue is List && rgbValue.length >= 3) {
      return [
        _clamp(rgbValue[0]),
        _clamp(rgbValue[1]),
        _clamp(rgbValue[2]),
      ];
    }
    // fall back to parsing hex
    final c = _hexToColor(hexValue?.toString() ?? '', const []);
    return [c.red, c.green, c.blue];
  }

  static int _clamp(dynamic v) {
    final n = (v is int) ? v : int.tryParse(v.toString()) ?? 0;
    return n.clamp(0, 255);
  }
}

/// ===================== PALETTE COLOR =====================
/// One selectable color on the CHOICE palette image.
class ColorLabPaletteColor {
  final String name;
  final String hex;
  final List<int> rgb;

  const ColorLabPaletteColor({
    required this.name,
    required this.hex,
    required this.rgb,
  });

  factory ColorLabPaletteColor.fromJson(Map<String, dynamic> json) {
    return ColorLabPaletteColor(
      name: (json['name'] ?? '').toString(),
      hex: (json['hex'] ?? '').toString(),
      rgb: ColorLabTargetColor._parseRgb(json['rgb'], json['hex']),
    );
  }

  Color get color => _hexToColor(hex, rgb);
}

/// ===================== HELPERS =====================
Color _hexToColor(String hex, List<int> fallbackRgb) {
  var cleaned = hex.trim().replaceAll('#', '');
  if (cleaned.length == 6) {
    final value = int.tryParse('FF$cleaned', radix: 16);
    if (value != null) return Color(value);
  }
  if (cleaned.length == 8) {
    final value = int.tryParse(cleaned, radix: 16);
    if (value != null) return Color(value);
  }
  if (fallbackRgb.length >= 3) {
    return Color.fromARGB(
      255,
      fallbackRgb[0],
      fallbackRgb[1],
      fallbackRgb[2],
    );
  }
  return const Color(0xFFCCCCCC);
}
