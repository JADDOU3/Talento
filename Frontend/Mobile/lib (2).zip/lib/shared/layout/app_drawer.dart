import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import '../../core/theme/app_colors.dart';
import '../../core/theme/app_text_styles.dart';
import '../../cubits/child_mode/child_mode_cubit.dart';
import '../../cubits/child_mode/child_mode_state.dart';
import '../../screens/auth/login_screen.dart';
import '../../screens/profile/profile_screen.dart';
import '../../services/auth/auth_service.dart';

class AppDrawer extends StatelessWidget {
  const AppDrawer({super.key});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: BlocConsumer<ChildModeCubit, ChildModeState>(
        listener: (context, state) {
          if (state is ChildModeError) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(
                content: Text(state.message),
                backgroundColor: AppColors.error,
              ),
            );
            context.read<ChildModeCubit>().checkChildMode();
          }
        },
        builder: (context, state) {
          final isChildMode = state is ChildModeStatus && state.isChildMode;
          final hasPin = state is ChildModeStatus && state.hasPin;
          final isLoading = state is ChildModeLoading;

          return SafeArea(
            child: Column(
              children: [
                // Header
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.symmetric(vertical: 32, horizontal: 20),
                  color: AppColors.primary,
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      const CircleAvatar(
                        radius: 30,
                        backgroundColor: Colors.white24,
                        child: Icon(Icons.person_rounded, color: Colors.white, size: 34),
                      ),
                      const SizedBox(height: 12),
                      Text(
                        'Talento',
                        style: AppTextStyles.bodyLarge.copyWith(
                          color: Colors.white,
                          fontWeight: FontWeight.w800,
                          fontSize: 20,
                        ),
                      ),
                    ],
                  ),
                ),

                const SizedBox(height: 8),

                // Profile
                _DrawerItem(
                  icon: Icons.person_outline_rounded,
                  label: 'الملف الشخصي',
                  onTap: () {
                    Navigator.pop(context);
                    Navigator.push(
                      context,
                      MaterialPageRoute(builder: (_) => const ProfileScreen()),
                    );
                  },
                ),

                // Child Mode Toggle
                _ChildModeItem(
                  isChildMode: isChildMode,
                  hasPin: hasPin,
                  isLoading: isLoading,
                  onTap: () => _handleChildModeTap(context, isChildMode, hasPin),
                ),

                // Settings
                _DrawerItem(
                  icon: Icons.settings_outlined,
                  label: 'الإعدادات',
                  onTap: () => Navigator.pop(context),
                ),

                const Spacer(),

                // Logout — hidden in child mode
                if (!isChildMode)
                  _DrawerItem(
                    icon: Icons.logout_rounded,
                    label: 'تسجيل الخروج',
                    color: AppColors.error,
                    onTap: () => _logout(context),
                  ),

                const SizedBox(height: 16),
              ],
            ),
          );
        },
      ),
    );
  }

  void _handleChildModeTap(BuildContext context, bool isChildMode, bool hasPin) {
    if (isChildMode) {
      _showDisablePinDialog(context);
    } else {
      if (!hasPin) {
        _showSetPinSheet(context);
      } else {
        context.read<ChildModeCubit>().enableChildMode();
        Navigator.pop(context);
      }
    }
  }

  void _showSetPinSheet(BuildContext context) {
    final pinController = TextEditingController();
    final confirmController = TextEditingController();

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      shape: const RoundedRectangleBorder(
        borderRadius: BorderRadius.vertical(top: Radius.circular(24)),
      ),
      builder: (ctx) => Padding(
        padding: EdgeInsets.only(
          bottom: MediaQuery.of(ctx).viewInsets.bottom + 24,
          top: 24,
          left: 24,
          right: 24,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text('تعيين رمز PIN', style: AppTextStyles.bodyLarge.copyWith(fontWeight: FontWeight.w800, fontSize: 18)),
            const SizedBox(height: 20),
            TextField(
              controller: pinController,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 4,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'أدخل PIN من 4 أرقام', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 12),
            TextField(
              controller: confirmController,
              obscureText: true,
              keyboardType: TextInputType.number,
              maxLength: 4,
              textAlign: TextAlign.center,
              decoration: const InputDecoration(hintText: 'تأكيد PIN', border: OutlineInputBorder()),
            ),
            const SizedBox(height: 16),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: () async {
                  if (pinController.text.length != 4) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('PIN يجب أن يكون 4 أرقام')),
                    );
                    return;
                  }
                  if (pinController.text != confirmController.text) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('PIN غير متطابق')),
                    );
                    return;
                  }
                  Navigator.pop(ctx);
                  await context.read<ChildModeCubit>().setPin(pinController.text);
                  if (context.mounted) {
                    await context.read<ChildModeCubit>().enableChildMode();
                    if (context.mounted) Navigator.pop(context);
                  }
                },
                child: const Text('تعيين PIN'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showDisablePinDialog(BuildContext context) {
    final pinController = TextEditingController();
    String? errorMsg;

    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setState) => AlertDialog(
          title: const Text('الخروج من وضع الطفل', textAlign: TextAlign.right),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: pinController,
                obscureText: true,
                keyboardType: TextInputType.number,
                maxLength: 4,
                textAlign: TextAlign.center,
                decoration: InputDecoration(
                  hintText: 'أدخل PIN',
                  border: const OutlineInputBorder(),
                  errorText: errorMsg,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('إلغاء'),
            ),
            ElevatedButton(
              onPressed: () async {
                try {
                  await context.read<ChildModeCubit>().disableChildMode(pinController.text);
                  if (ctx.mounted) Navigator.pop(ctx);
                  if (context.mounted) Navigator.pop(context);
                } catch (_) {
                  setState(() => errorMsg = 'PIN غير صحيح');
                }
              },
              child: const Text('تأكيد'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _logout(BuildContext context) async {
    context.read<ChildModeCubit>().reset();
    await AuthService().logout();
    if (context.mounted) {
      Navigator.pushAndRemoveUntil(
        context,
        MaterialPageRoute(builder: (_) => const LoginScreen()),
        (route) => false,
      );
    }
  }
}

class _DrawerItem extends StatelessWidget {
  final IconData icon;
  final String label;
  final VoidCallback onTap;
  final Color? color;

  const _DrawerItem({
    required this.icon,
    required this.label,
    required this.onTap,
    this.color,
  });

  @override
  Widget build(BuildContext context) {
    final c = color ?? AppColors.textPrimary;
    return ListTile(
      leading: Icon(icon, color: c),
      title: Text(label, style: AppTextStyles.bodyLarge.copyWith(color: c, fontSize: 15)),
      onTap: onTap,
    );
  }
}

class _ChildModeItem extends StatelessWidget {
  final bool isChildMode;
  final bool hasPin;
  final bool isLoading;
  final VoidCallback onTap;

  const _ChildModeItem({
    required this.isChildMode,
    required this.hasPin,
    required this.isLoading,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return ListTile(
      leading: isLoading
          ? const SizedBox(width: 24, height: 24, child: CircularProgressIndicator(strokeWidth: 2))
          : Icon(
              Icons.child_care_rounded,
              color: isChildMode ? AppColors.primary : AppColors.textSecondary,
            ),
      title: Text(
        isChildMode ? 'وضع الطفل نشط' : 'وضع الطفل',
        style: AppTextStyles.bodyLarge.copyWith(
          fontSize: 15,
          color: isChildMode ? AppColors.primary : AppColors.textPrimary,
          fontWeight: isChildMode ? FontWeight.w700 : FontWeight.w400,
        ),
      ),
      subtitle: !isChildMode && !hasPin
          ? Text('لم يتم تعيين PIN', style: AppTextStyles.bodyMedium.copyWith(fontSize: 12, color: AppColors.hint))
          : null,
      trailing: Switch(
        value: isChildMode,
        onChanged: isLoading ? null : (_) => onTap(),
        activeColor: AppColors.primary,
      ),
      onTap: isLoading ? null : onTap,
    );
  }
}
