import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../models/color_lab/color_lab_models.dart';

/// Shows the palette (CHOICE) image at the bottom of the screen and overlays
/// invisible tap zones for each color slot.
///
/// Coordinates: the design team will provide exact tap-zone positions. Until
/// those arrive, slots are distributed evenly across the image width using a
/// fixed aspect ratio + LayoutBuilder (so it stays responsive).
class ColorPaletteWidget extends StatelessWidget {
  final ColorLabImage paletteImage;
  final ValueChanged<ColorLabPaletteColor> onColorPicked;

  /// Aspect ratio of the palette image (width / height).
  /// Adjust when the design team confirms the real asset ratio.
  final double aspectRatio;

  const ColorPaletteWidget({
    super.key,
    required this.paletteImage,
    required this.onColorPicked,
    this.aspectRatio = 2.6,
  });

  @override
  Widget build(BuildContext context) {
    final slots = paletteImage.slots > 0 ? paletteImage.slots : 5;
    final colors = _resolveColors(slots);

    return Container(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(24),
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withValues(alpha: 0.05),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      clipBehavior: Clip.antiAlias,
      child: AspectRatio(
        aspectRatio: aspectRatio,
        child: LayoutBuilder(
          builder: (context, constraints) {
            final slotWidth = constraints.maxWidth / slots;

            return Stack(
              children: [
                // Palette image
                Positioned.fill(
                  child: paletteImage.hasImage
                      ? Image.network(
                          paletteImage.url,
                          fit: BoxFit.cover,
                          errorBuilder: (_, __, ___) =>
                              _fallbackPalette(colors),
                        )
                      : _fallbackPalette(colors),
                ),

                // Invisible (or subtly highlighted) tap zones
                for (int i = 0; i < slots; i++)
                  Positioned(
                    left: i * slotWidth,
                    top: 0,
                    bottom: 0,
                    width: slotWidth,
                    child: GestureDetector(
                      behavior: HitTestBehavior.opaque,
                      onTap: () {
                        if (i < colors.length) {
                          onColorPicked(colors[i]);
                        }
                      },
                      child: Container(
                        color: Colors.transparent,
                      ),
                    ),
                  ),
              ],
            );
          },
        ),
      ),
    );
  }

  /// Use colors from meta if backend supplies them; otherwise fall back to a
  /// default primary set so the game stays playable during integration.
  List<ColorLabPaletteColor> _resolveColors(int slots) {
    final fromMeta = paletteImage.paletteColors;
    if (fromMeta.isNotEmpty) return fromMeta;

    // Fallback palette (red, yellow, blue, white, black) — matches the
    // mixing lessons in the design doc (red+yellow=orange, blue+red=purple…).
    const fallback = [
      ColorLabPaletteColor(name: 'أحمر', hex: '#FF0000', rgb: [255, 0, 0]),
      ColorLabPaletteColor(name: 'أصفر', hex: '#FFD60A', rgb: [255, 214, 10]),
      ColorLabPaletteColor(name: 'أزرق', hex: '#0066FF', rgb: [0, 102, 255]),
      ColorLabPaletteColor(name: 'أبيض', hex: '#FFFFFF', rgb: [255, 255, 255]),
      ColorLabPaletteColor(name: 'أسود', hex: '#000000', rgb: [0, 0, 0]),
    ];

    return fallback.take(slots).toList();
  }

  /// Drawn palette when there is no image — shows the actual swatches so the
  /// child can still tap meaningful colors.
  Widget _fallbackPalette(List<ColorLabPaletteColor> colors) {
    return Row(
      children: colors
          .map(
            (c) => Expanded(
              child: Container(color: c.color),
            ),
          )
          .toList(),
    );
  }
}
