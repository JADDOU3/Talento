import 'package:flutter/material.dart';

import '../../../core/theme/app_colors.dart';
import '../../../core/theme/app_text_styles.dart';
import '../../../models/color_lab/color_lab_models.dart';

/// Shows the colors the child has picked and the resulting mixed color.
class MixingBowlWidget extends StatelessWidget {
  final List<ColorLabPaletteColor> selectedColors;

  const MixingBowlWidget({
    super.key,
    required this.selectedColors,
  });

  /// Average the picked colors to preview the mix.
  Color get _mixedColor {
    if (selectedColors.isEmpty) {
      return AppColors.inputFill;
    }
    int r = 0, g = 0, b = 0;
    for (final c in selectedColors) {
      r += c.rgb[0];
      g += c.rgb[1];
      b += c.rgb[2];
    }
    final n = selectedColors.length;
    return Color.fromARGB(
      255,
      (r / n).round(),
      (g / n).round(),
      (b / n).round(),
    );
  }

  @override
  Widget build(BuildContext context) {
    final hasColors = selectedColors.isNotEmpty;

    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.white,
        borderRadius: BorderRadius.circular(26),
        border: Border.all(color: AppColors.border),
        boxShadow: [
          BoxShadow(
            color: AppColors.black.withValues(alpha: 0.04),
            blurRadius: 14,
            offset: const Offset(0, 6),
          ),
        ],
      ),
      child: Row(
        children: [
          // Mixed result circle (the "bowl")
          AnimatedContainer(
            duration: const Duration(milliseconds: 300),
            width: 72,
            height: 72,
            decoration: BoxDecoration(
              color: _mixedColor,
              shape: BoxShape.circle,
              border: Border.all(
                color: AppColors.white,
                width: 3,
              ),
              boxShadow: [
                BoxShadow(
                  color: hasColors
                      ? _mixedColor.withValues(alpha: 0.45)
                      : Colors.transparent,
                  blurRadius: 16,
                  spreadRadius: 1,
                ),
              ],
            ),
            child: hasColors
                ? null
                : const Icon(
                    Icons.science_outlined,
                    color: AppColors.hint,
                    size: 28,
                  ),
          ),

          const SizedBox(width: 16),

          // Picked colors row
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  hasColors ? 'ألوانك المختارة' : 'اختر لونًا لتبدأ الخلط',
                  style: AppTextStyles.bodyMedium.copyWith(
                    color: AppColors.textSecondary,
                    fontWeight: FontWeight.w700,
                    fontSize: 12.5,
                  ),
                ),
                const SizedBox(height: 8),
                SizedBox(
                  height: 30,
                  child: hasColors
                      ? ListView.separated(
                          scrollDirection: Axis.horizontal,
                          itemCount: selectedColors.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(width: 6),
                          itemBuilder: (context, index) {
                            final c = selectedColors[index];
                            return Container(
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                color: c.color,
                                shape: BoxShape.circle,
                                border: Border.all(
                                  color: AppColors.white,
                                  width: 2,
                                ),
                                boxShadow: [
                                  BoxShadow(
                                    color: AppColors.black
                                        .withValues(alpha: 0.08),
                                    blurRadius: 4,
                                    offset: const Offset(0, 2),
                                  ),
                                ],
                              ),
                            );
                          },
                        )
                      : Row(
                          children: List.generate(
                            3,
                            (i) => Container(
                              margin: const EdgeInsets.only(left: 6),
                              width: 30,
                              height: 30,
                              decoration: BoxDecoration(
                                color: AppColors.inputFill,
                                shape: BoxShape.circle,
                                border: Border.all(color: AppColors.border),
                              ),
                            ),
                          ),
                        ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
