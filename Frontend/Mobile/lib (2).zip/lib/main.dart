import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';

import 'core/lifecycle/app_lifecycle_handler.dart';
import 'core/theme/app_theme.dart';
import 'cubits/child_mode/child_mode_cubit.dart';
import 'cubits/coins/coins_cubit.dart';
import 'screens/splash/splash_screen.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({
    super.key,
  });

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider<ChildModeCubit>(
          create: (_) => ChildModeCubit(),
        ),
        BlocProvider<CoinsCubit>(
          create: (_) => CoinsCubit(),
        ),
      ],
      child: AppLifecycleHandler(
        child: MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Talento',
          theme: AppTheme.lightTheme,
          builder: (context, child) {
            return Directionality(
              textDirection: TextDirection.rtl,
              child: child!,
            );
          },
          home: const SplashScreen(),
        ),
      ),
    );
  }
}