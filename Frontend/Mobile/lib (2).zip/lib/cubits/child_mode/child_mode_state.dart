abstract class ChildModeState {}

class ChildModeInitial extends ChildModeState {}

class ChildModeLoading extends ChildModeState {}

class ChildModeStatus extends ChildModeState {
  final bool isChildMode;
  final bool hasPin;
  ChildModeStatus({required this.isChildMode, required this.hasPin});
}

class ChildModePinRequired extends ChildModeState {}

class ChildModeError extends ChildModeState {
  final String message;
  ChildModeError(this.message);
}
