import 'package:flutter_bloc/flutter_bloc.dart';
import '../../services/child_mode_service.dart';
import 'child_mode_state.dart';

class ChildModeCubit extends Cubit<ChildModeState> {
  final ChildModeService _service = ChildModeService();

  ChildModeCubit() : super(ChildModeInitial());

  Future<void> checkChildMode() async {
    emit(ChildModeLoading());
    try {
      final isChildMode = await _service.isChildMode();
      final hasPin = await _service.hasPin();
      emit(ChildModeStatus(isChildMode: isChildMode, hasPin: hasPin));
    } catch (e) {
      emit(ChildModeError(e.toString()));
    }
  }

  Future<void> enableChildMode() async {
    emit(ChildModeLoading());
    try {
      await _service.enableChildMode();
      final hasPin = await _service.hasPin();
      emit(ChildModeStatus(isChildMode: true, hasPin: hasPin));
    } catch (e) {
      emit(ChildModeError(e.toString()));
    }
  }

  Future<void> disableChildMode(String pin) async {
    emit(ChildModeLoading());
    try {
      await _service.disableChildMode(pin);
      emit(ChildModeStatus(isChildMode: false, hasPin: true));
    } catch (e) {
      emit(ChildModeError(e.toString()));
    }
  }

  Future<void> setPin(String pin) async {
    emit(ChildModeLoading());
    try {
      await _service.setPin(pin);
      emit(ChildModeStatus(isChildMode: false, hasPin: true));
    } catch (e) {
      emit(ChildModeError(e.toString()));
    }
  }

  Future<bool> hasPin() async {
    try {
      return await _service.hasPin();
    } catch (_) {
      return false;
    }
  }

  void reset() {
    emit(ChildModeInitial());
  }
}
